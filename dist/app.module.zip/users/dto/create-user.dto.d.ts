export declare class CreateUserDto {
    phoneNumber: string;
    name?: string;
    max_credits?: number;
    settings?: Record<string, any>;
}
