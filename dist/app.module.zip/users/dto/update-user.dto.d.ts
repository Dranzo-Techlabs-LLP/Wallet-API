export declare class UpdateUserDto {
    phoneNumber?: string;
    max_credits?: number;
    name?: string;
    settings?: Record<string, any>;
}
