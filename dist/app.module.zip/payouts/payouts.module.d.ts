export declare class PayoutsModule {
}
