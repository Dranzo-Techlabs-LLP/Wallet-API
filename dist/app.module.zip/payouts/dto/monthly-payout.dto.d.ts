export declare class MonthlyPayoutDto {
    expertId: string;
    month: string;
    payoutThreshold: number;
}
