export declare class Expert {
    id: string;
    expertId: string;
    bankAccountDetails: Record<string, any>;
    currentWalletBalance: number;
    createdAt: Date;
    updatedAt: Date;
}
