export declare class AdjustSessionDto {
    sessionId: string;
    adjustedFee: number;
    deferFee: boolean;
}
