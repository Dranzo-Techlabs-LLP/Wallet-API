export declare class EndSessionDto {
    sessionId: string;
    expertId: string;
    actualFee: number;
}
