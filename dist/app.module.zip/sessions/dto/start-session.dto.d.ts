export declare class StartSessionDto {
    userId: string;
    expertId: string;
    sessionFee: number;
}
