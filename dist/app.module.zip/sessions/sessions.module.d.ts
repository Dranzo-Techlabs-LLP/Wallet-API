export declare class SessionsModule {
}
